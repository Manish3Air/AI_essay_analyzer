# ml/train_t5_grammar.py

import os
import json
import random
from datasets import Dataset, load_dataset



from transformers import (
    T5TokenizerFast,
    T5ForConditionalGeneration,
    Seq2SeqTrainer,
    Seq2SeqTrainingArguments,
    DataCollatorForSeq2Seq,
)
import evaluate


# ---------------------------
# Load JSONL safely
# ---------------------------
def load_jsonl(path):
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                items.append(json.loads(line))
    return items


# ---------------------------
# Load & split data
# ---------------------------

# train = load_jsonl("ml/data/grammar_train.jsonl")
ds = load_dataset("Owishiboo/grammar-correction")
train = ds["train"].to_list()

assert len(train) > 0, "Grammar training data is empty!"

random.shuffle(train)

# 80-20 split (safe for small datasets)
split_idx = max(1, int(0.8 * len(train)))
train_data = train[:split_idx]
val_data = train[split_idx:]

print(f"Train samples: {len(train_data)}")
print(f"Val samples: {len(val_data)}")

train_ds = Dataset.from_list([
    {"input_text": "correct: " + x["original"], "target_text": x["corrected"]}
    for x in train_data
])

val_ds = Dataset.from_list([
    {"input_text": "correct: " + x["original"], "target_text": x["corrected"]}
    for x in val_data
])


# ---------------------------
# Model & tokenizer
# ---------------------------
model_name = "t5-small"
tokenizer = T5TokenizerFast.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)

max_input_len = 256
max_target_len = 128


# ---------------------------
# Preprocessing
# ---------------------------
def preprocess(batch):
    inputs = tokenizer(
        batch["input_text"],
        truncation=True,
        max_length=max_input_len,
        padding="max_length",
    )
    targets = tokenizer(
        batch["target_text"],
        truncation=True,
        max_length=max_target_len,
        padding="max_length",
    )

    inputs["labels"] = targets["input_ids"]
    return inputs


train_ds = train_ds.map(preprocess, batched=True)
val_ds = val_ds.map(preprocess, batched=True)

train_ds = train_ds.remove_columns(["input_text", "target_text"])
val_ds = val_ds.remove_columns(["input_text", "target_text"])


# ---------------------------
# Training setup
# ---------------------------
data_collator = DataCollatorForSeq2Seq(tokenizer, model=model)
rouge = evaluate.load("rouge")

training_args = Seq2SeqTrainingArguments(
    output_dir="ml/outputs/t5-grammar",
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    predict_with_generate=True,
    logging_steps=10,
    num_train_epochs=3,
    learning_rate=5e-5,
    fp16=False,
    save_total_limit=2,
)



# ---------------------------
# Metrics (FIXED)
# ---------------------------
def compute_metrics(eval_pred):
    preds, labels = eval_pred

    labels = [
        [(l if l != -100 else tokenizer.pad_token_id) for l in label]
        for label in labels
    ]

    decoded_preds = tokenizer.batch_decode(preds, skip_special_tokens=True)
    decoded_labels = tokenizer.batch_decode(labels, skip_special_tokens=True)

    result = rouge.compute(
        predictions=decoded_preds,
        references=decoded_labels,
    )

    return {
        "rouge1": result["rouge1"].mid.fmeasure,
        "rougeL": result["rougeL"].mid.fmeasure,
    }


# ---------------------------
# Train
# ---------------------------
trainer = Seq2SeqTrainer(
    model=model,
    args=training_args,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    tokenizer=tokenizer,
    data_collator=data_collator,
    compute_metrics=compute_metrics,
)

trainer.train()

trainer.save_model("ml/outputs/t5-grammar-final")
tokenizer.save_pretrained("ml/outputs/t5-grammar-final")
